# Overview


# Usage


# Install


# Reasoning
Why not keep business logic in Python only? Performance
Why not keep business logic in SQL only? Portability


# Features
- [ ] Diff SQL queries
- [ ] Identify filtering in join and where clauses (model this)

Move to BLU
- [ ] Identify logic units in SQL queries
- [ ] SQL query builder based on logic units
- [ ] Python logic-unit function
- [ ] Python record-set function
- [ ] Django method to include logic-unit fields
- [ ] Django queryset filter based on logic-unit
- [ ] Same logic units used for applications, data-warehouse extracts, ad-hoc querying
- [ ] Data dictionary
